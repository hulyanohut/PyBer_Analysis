# Google API key
g_key = "AIzaSyCFkCApogM7HOgwVsZsKVDucDtaSJDCIIg"
